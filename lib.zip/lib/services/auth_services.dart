import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  // key untuk SharedPreferences
  static const String _keyLoggedIn = 'isLoggedIn';

  /// Tandai user sudah login
  static Future<void> login() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyLoggedIn, true);
  }

  /// Logout: reset flag login
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_keyLoggedIn, false);
  }

  /// Cek status login
  static Future<bool> get isLoggedIn async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_keyLoggedIn) ?? false;
  }
}
